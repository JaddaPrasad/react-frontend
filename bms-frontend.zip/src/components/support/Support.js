import React,{useState} from 'react'
import { Redirect } from 'react-router-dom'
import Cookies from 'universal-cookie';
import { useHistory } from 'react-router-dom'

export const Support = () => {

    const cookies = new Cookies();
    let history = useHistory()
    const username=cookies.get('username')
    if(username==='' || username==null){
        history.push('/login')
    }

    const initValues={
        customerId:'',
        querytext:'',
        createddate:'',
        updateddate:'',
        timestamp:''
    }

    const [query,setQuery]=useState(initValues)

    const handleInput = e => {
        setQuery({ ...query, [e.target.name]: e.target.value })
    }

    const handleSubmit = e => {
        e.preventDefault()
        console.log(query);
        setQuery(initValues)
    }

    return (
        <div>
            <form onSubmit={handleSubmit}>
            <div className="textarea-div">
                <textarea rows="3" type="text" className="form-control flex-item" value={query.querytext} name="querytext" placeholder="Enter your query here"
                    onChange={handleInput}
                />
            </div>
            <button type="submit" className="btn btn-outline-primary">Submit</button>
            </form>
        </div>
    )
}
