import React from 'react'

export const loan = () => {
    
    const addLoan=()=>{

    }

    const getLoanDetails=()=>{

    }
    
    const updateLoan=()=>{

    }

    const deleteLoan=()=>{

    }

}
