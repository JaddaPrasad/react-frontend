import React from 'react'

export const login = () => {

    const _url="https://jsonplaceholder.typicode.com/posts/"

    const register=(user)=>{
        // axios.post(_url,user)
        // .then(res=>{
        //     console.log(res);
        //     setUser(res.data)
        // })
        // .catch(err=>{
        //     console.log(err);
        // })
    }

    const login=(username,password)=>{
        
    }

    const getUserDetails=(userid)=>{
        
    }

    const updateUserDetails=(user)=>{

    }
    
}
