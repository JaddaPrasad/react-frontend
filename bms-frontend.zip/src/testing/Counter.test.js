import Enzyme,{shallow, ShallowWrapper} from 'enzyme'
import EnzymeAdapter from '@wojtekmaj/enzyme-adapter-react-17';
import {Counter} from './Counter'
import { Component } from 'react';

Enzyme.configure({adapter: new EnzymeAdapter()})

/**
 * Factory function to create shallow wrapper for Counter Component
 * @function setup
 * @returns {ShallowWrapper}
 */
const setup=()=> shallow(<Counter/>);

const findTestByAttr= (wrapper,val) => wrapper.find(`[data-test='${val}']`);

test('renders without error',()=>{

    const counter= setup()
    //const counterComponent=counter.find("[data-test='component-counter']")
    const counterComponent=findTestByAttr(counter,"component-counter")
    expect(counterComponent.length).toBe(1);
})

test('renders increment button',()=>{
    const counter= setup()
    const button=findTestByAttr(counter,"increment-button")
    expect(button.length).toBe(1);
})

test('renders counter display',()=>{
    const counter= setup()
    const counterDisplay=findTestByAttr(counter,"counter-display")
    expect(counterDisplay.length).toBe(1);
})

test('counter display starts at 0',()=>{
    const counter= setup()
    const countVal=findTestByAttr(counter,"count").text()
    expect(countVal).toBe("0");
})

test('clicking button increment counter display',()=>{
    const counter= setup()

    //find the button
    const button=findTestByAttr(counter,"increment-button")

    //click the button
    button.simulate('click');

    //find the display, and test the number has been incremented 
    const countVal=findTestByAttr(counter,"count").text()
    expect(countVal).toBe("1");
})

test('clicking button decrement counter display',()=>{
    const counter= setup()

    //find the button
    const button=findTestByAttr(counter,"decrement-button")

    //click the button
    button.simulate('click');

    //find the display, and test the number has been incremented 
    const countVal=findTestByAttr(counter,"count").text()
    if(countVal==="0"){
        throw new Error("counter can't go below zero");
    }
    //expect(countVal).toBe("0");
})